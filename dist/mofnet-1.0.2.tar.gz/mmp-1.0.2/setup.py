from setuptools import setup

setup(
    name="mmp",
    version="1.0.2",
    author="Samir Baladi",
    packages=["mmp"],
)
