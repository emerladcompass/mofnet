#!/usr/bin/env python3
"""
Basic usage example for MMP package.
"""

import mmp

def main():
print("MMP - Medical MOF Prediction Example")
print("=" * 40)

if name == "main":
main()
