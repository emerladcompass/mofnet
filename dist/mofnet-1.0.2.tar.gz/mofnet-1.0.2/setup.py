from setuptools import setup, find_packages

# قراءة الوصف
with open("README.md", "r", encoding="utf-8") as f:
    long_desc = f.read()

setup(
    name="mofnet",
    version="1.0.2",
    author="Samir Baladi",
    author_email="emerladcompass@gmail.com",
    description="Multi-Organ Failure Network - Clinical Prediction System",
    long_description=long_desc,
    long_description_content_type="text/markdown",
    url="https://github.com/emerladcompass/mofnet",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Healthcare Industry",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
        "Topic :: Scientific/Engineering :: Medical Science Apps.",
    ],
    python_requires=">=3.6",
    install_requires=[
        "numpy>=1.21.0",
        "pandas>=1.3.0",
    ],
)
